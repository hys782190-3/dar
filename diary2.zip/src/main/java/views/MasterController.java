package views;

public class MasterController {
	
}
